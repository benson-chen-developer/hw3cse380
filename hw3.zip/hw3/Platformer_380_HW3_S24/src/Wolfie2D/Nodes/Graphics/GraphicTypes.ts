export enum GraphicType {
	POINT = "POINT",
	RECT = "RECT",
	LINE = "LINE",
	PARTICLE = "PARTICLE"
}
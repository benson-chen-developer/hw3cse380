export enum HW5_Color {
    RED = "red",
    BLUE = "blue",
    GREEN = "green"
}